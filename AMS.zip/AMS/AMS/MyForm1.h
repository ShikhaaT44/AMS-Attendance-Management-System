#pragma once
#include<iostream>
#include<windows.h>
#include<strsafe.h>
#include<cctype>
#include<thread>
#include<regex>
namespace AMS {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Diagnostics;
	using namespace System::IO;
   using namespace System::Text::RegularExpressions;
   using namespace System::Net::Mail;
   using namespace System::Globalization;
	/// <summary>
	/// Summary for MyForm1
	/// </summary>
	public ref class MyForm1 : public System::Windows::Forms::Form
	{
	public:
		MyForm1(void)
		{
			InitializeComponent();
			this->SetStyle(
				ControlStyles::AllPaintingInWmPaint |
				ControlStyles::UserPaint |
				ControlStyles::DoubleBuffer,
				true);
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Panel^ panel1;
	protected:


	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::TextBox^ textBox1;
	private: System::Windows::Forms::Label^ label5;

	private: System::Windows::Forms::TextBox^ textBox2;
	private: System::Windows::Forms::Label^ label7;

	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::TextBox^ textBox3;
	private: System::Windows::Forms::Label^ label8;
	private: System::Windows::Forms::TextBox^ textBox4;
	private: System::Windows::Forms::Label^ label9;
	private: System::Windows::Forms::TextBox^ textBox5;
	private: System::Windows::Forms::Label^ label10;
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::ComboBox^ comboBox1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(MyForm1::typeid));
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->textBox4 = (gcnew System::Windows::Forms::TextBox());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->textBox5 = (gcnew System::Windows::Forms::TextBox());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->panel1->SuspendLayout();
			this->SuspendLayout();
			// 
			// comboBox1
			// 
			this->comboBox1->BackColor = System::Drawing::Color::White;
			this->comboBox1->Cursor = System::Windows::Forms::Cursors::Arrow;
			this->comboBox1->Font = (gcnew System::Drawing::Font(L"JetBrains Mono", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(10) {
				L"1", L"2", L"3", L"4", L"5", L"6", L"7", L"8",
					L"9", L"10"
			});
			this->comboBox1->Location = System::Drawing::Point(762, 230);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(260, 30);
			this->comboBox1->TabIndex = 11;
			// 
			// panel1
			// 
			this->panel1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"panel1.BackgroundImage")));
			this->panel1->Controls->Add(this->label3);
			this->panel1->Controls->Add(this->label2);
			this->panel1->Controls->Add(this->label1);
			this->panel1->Dock = System::Windows::Forms::DockStyle::Left;
			this->panel1->Location = System::Drawing::Point(0, 0);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(371, 688);
			this->panel1->TabIndex = 0;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"JetBrains Mono", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"label3.Image")));
			this->label3->Location = System::Drawing::Point(53, 386);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(117, 19);
			this->label3->TabIndex = 7;
			this->label3->Text = L"Presented by";
			this->label3->TextAlign = System::Drawing::ContentAlignment::TopCenter;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Segoe Script", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"label2.Image")));
			this->label2->Location = System::Drawing::Point(158, 385);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(131, 23);
			this->label2->TabIndex = 6;
			this->label2->Text = L"  Secretself Info";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::Color::White;
			this->label1->Font = (gcnew System::Drawing::Font(L"JetBrains Mono", 48, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"label1.Image")));
			this->label1->Location = System::Drawing::Point(43, 259);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(285, 106);
			this->label1->TabIndex = 1;
			this->label1->Text = L"A M S";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"JetBrains Mono", 24, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(149)),
				static_cast<System::Int32>(static_cast<System::Byte>(211)));
			this->label4->Location = System::Drawing::Point(633, 23);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(191, 53);
			this->label4->TabIndex = 4;
			this->label4->Text = L"Sign Up";
			// 
			// textBox1
			// 
			this->textBox1->AutoCompleteMode = System::Windows::Forms::AutoCompleteMode::Append;
			this->textBox1->Font = (gcnew System::Drawing::Font(L"JetBrains Mono", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox1->Location = System::Drawing::Point(432, 156);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(590, 30);
			this->textBox1->TabIndex = 5;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Arial", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(149)),
				static_cast<System::Int32>(static_cast<System::Byte>(211)));
			this->label5->Location = System::Drawing::Point(448, 139);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(101, 22);
			this->label5->TabIndex = 6;
			this->label5->Text = L"Full Name";
			// 
			// textBox2
			// 
			this->textBox2->Font = (gcnew System::Drawing::Font(L"JetBrains Mono", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox2->Location = System::Drawing::Point(432, 230);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(283, 30);
			this->textBox2->TabIndex = 8;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Arial", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label7->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(149)),
				static_cast<System::Int32>(static_cast<System::Byte>(211)));
			this->label7->Location = System::Drawing::Point(447, 214);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(78, 22);
			this->label7->TabIndex = 9;
			this->label7->Text = L"Course";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Arial", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(149)),
				static_cast<System::Int32>(static_cast<System::Byte>(211)));
			this->label6->Location = System::Drawing::Point(778, 213);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(98, 22);
			this->label6->TabIndex = 12;
			this->label6->Text = L"Semester";
			// 
			// textBox3
			// 
			this->textBox3->AutoCompleteMode = System::Windows::Forms::AutoCompleteMode::Suggest;
			this->textBox3->AutoCompleteSource = System::Windows::Forms::AutoCompleteSource::HistoryList;
			this->textBox3->Font = (gcnew System::Drawing::Font(L"JetBrains Mono", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox3->Location = System::Drawing::Point(432, 304);
			this->textBox3->Name = L"textBox3";
			this->textBox3->Size = System::Drawing::Size(590, 30);
			this->textBox3->TabIndex = 13;
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Font = (gcnew System::Drawing::Font(L"Arial", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label8->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(149)),
				static_cast<System::Int32>(static_cast<System::Byte>(211)));
			this->label8->Location = System::Drawing::Point(448, 287);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(61, 22);
			this->label8->TabIndex = 14;
			this->label8->Text = L"Email";
			// 
			// textBox4
			// 
			this->textBox4->AutoCompleteMode = System::Windows::Forms::AutoCompleteMode::Suggest;
			this->textBox4->AutoCompleteSource = System::Windows::Forms::AutoCompleteSource::HistoryList;
			this->textBox4->Font = (gcnew System::Drawing::Font(L"Arial", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox4->Location = System::Drawing::Point(432, 378);
			this->textBox4->MaxLength = 8;
			this->textBox4->Name = L"textBox4";
			this->textBox4->Size = System::Drawing::Size(590, 27);
			this->textBox4->TabIndex = 15;
			this->textBox4->UseSystemPasswordChar = true;
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Font = (gcnew System::Drawing::Font(L"Arial", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label9->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(149)),
				static_cast<System::Int32>(static_cast<System::Byte>(211)));
			this->label9->Location = System::Drawing::Point(448, 360);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(103, 22);
			this->label9->TabIndex = 16;
			this->label9->Text = L"Password";
			// 
			// textBox5
			// 
			this->textBox5->AutoCompleteMode = System::Windows::Forms::AutoCompleteMode::Suggest;
			this->textBox5->AutoCompleteSource = System::Windows::Forms::AutoCompleteSource::HistoryList;
			this->textBox5->Font = (gcnew System::Drawing::Font(L"Arial", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox5->Location = System::Drawing::Point(432, 446);
			this->textBox5->MaxLength = 8;
			this->textBox5->Name = L"textBox5";
			this->textBox5->Size = System::Drawing::Size(590, 27);
			this->textBox5->TabIndex = 17;
			this->textBox5->UseSystemPasswordChar = true;
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->BackColor = System::Drawing::Color::Transparent;
			this->label10->Font = (gcnew System::Drawing::Font(L"Arial", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label10->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(149)),
				static_cast<System::Int32>(static_cast<System::Byte>(211)));
			this->label10->Location = System::Drawing::Point(448, 429);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(186, 22);
			this->label10->TabIndex = 18;
			this->label10->Text = L"Re-enter Password";
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::Black;
			this->button1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button1.BackgroundImage")));
			this->button1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->button1->FlatAppearance->BorderColor = System::Drawing::Color::CornflowerBlue;
			this->button1->FlatAppearance->BorderSize = 2;
			this->button1->FlatAppearance->MouseOverBackColor = System::Drawing::Color::Transparent;
			this->button1->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button1->Font = (gcnew System::Drawing::Font(L"JetBrains Mono", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button1->ForeColor = System::Drawing::Color::White;
			this->button1->Location = System::Drawing::Point(524, 548);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(191, 37);
			this->button1->TabIndex = 19;
			this->button1->Text = L"SIGN UP";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm1::button1_Click);
			// 
			// button2
			// 
			this->button2->FlatAppearance->BorderColor = System::Drawing::Color::CornflowerBlue;
			this->button2->FlatAppearance->BorderSize = 2;
			this->button2->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button2->Font = (gcnew System::Drawing::Font(L"JetBrains Mono", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button2->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(32)), static_cast<System::Int32>(static_cast<System::Byte>(148)),
				static_cast<System::Int32>(static_cast<System::Byte>(210)));
			this->button2->Location = System::Drawing::Point(762, 548);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(191, 37);
			this->button2->TabIndex = 20;
			this->button2->Text = L"EXIT";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &MyForm1::button2_Click);
			// 
			// MyForm1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->AutoSizeMode = System::Windows::Forms::AutoSizeMode::GrowAndShrink;
			this->BackColor = System::Drawing::Color::White;
			this->ClientSize = System::Drawing::Size(1095, 688);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->label10);
			this->Controls->Add(this->textBox5);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->textBox4);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->textBox3);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->comboBox1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Name = L"MyForm1";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"MyForm1";
			this->Load += gcnew System::EventHandler(this, &MyForm1::MyForm1_Load);
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	


private: System::Void MyForm1_Load(System::Object^ sender, System::EventArgs^ e) {
}
//has Digit or not in string
bool ISNumeric(String^ str)
{
	bool hasNumber = false;
	for (int i = 0;i < str->Length;i++)
	{
		if (Char::IsNumber(str[i]))
		{
			hasNumber = true;
			break;
		}
	}
	return hasNumber;
}
//has special symbols or not in string
bool ISSpecialSymbols(String^ str)
{
	bool hasSpecialChar = false;
	Char special[] = { '@', '#', '$', '%', '^', '&', '+', '=' };
	for (int i = 0;i < str->Length;i++)
	{
		for (int j = 0;j < 8;j++)
		{
			if (str[i] == special[j])
			{
				hasSpecialChar = true;
				break;
			}
			if (hasSpecialChar)
				break;
		}
	}
	return hasSpecialChar;
}
//Choice validation 
bool validateChoice(String^ input, int Bnd) //* string input validate as integer
{

	bool flag = false;
	for (int tem = 1;tem <= Bnd;tem++)
	{

		if (tem.ToString() == input) //convert tem int to string to check input valid condition
		{
			flag = true;
			break;
		}
	}
	return flag;
}
private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
	if (textBox1->Text->Length == 0)//Empty Name box
	{
		MessageBox::Show("Please Enter Your Name!", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}	
	if (ISNumeric(textBox1->Text))//Numeric Error
	{
		MessageBox::Show("Name doesn't contain Digits!", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		textBox1->Text = "";
		return;
	}	
	if (ISSpecialSymbols(textBox1->Text))//Special Symbols Error
	{
		MessageBox::Show("Name doesn't contain Special Symbols!", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		textBox1->Text = "";
		return;
	}
	if (textBox2->Text->Length == 0)//Course Error
	{
		MessageBox::Show("Please Enter Course Details!", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}
	if (ISNumeric(textBox2->Text))//Numeric Error
	{
		MessageBox::Show("Course Name doesn't contain Digits!", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		textBox2->Text = "";
		return;
	}
	if (ISSpecialSymbols(textBox2->Text))//Special Symbols Error
	{
		MessageBox::Show("Course Name doesn't contain Special Symbols!", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		textBox2->Text = "";
		return;
	}
	if (comboBox1->Text->Length == 0)//Semester combobox empty
	{
		MessageBox::Show("Please Select Your Semester!", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}
	if (!validateChoice(comboBox1->Text,10))//validate choice
	{
		MessageBox::Show("Please Enter a Valid  Semester!", "INVALID SEMESTER", MessageBoxButtons::OK, MessageBoxIcon::Error);
		comboBox1->Text = "";
		return;
	}
	if (textBox3->Text->Length == 0)//Email box Empty
	{
		MessageBox::Show("Please Enter Your Email Address!", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}
	else
	{
		//validate email
		Regex^ regex = gcnew Regex("(\\w+)(\\.|_)?(\\w*)@(\\w+)(\\.(\\w+))+");
		bool isValidEmail = regex->IsMatch(textBox3->Text);
		if (!isValidEmail || textBox3->Text->IndexOf(" ") != -1) {

			MessageBox::Show("Please Enter a Valid Email Address!", "INVALID EMAIL ADDRESS", MessageBoxButtons::OK, MessageBoxIcon::Error);
			textBox3->Text = "";
			return;
		}
	}
	if (textBox4->Text->Length == 0)//Empty Password
	{
		MessageBox::Show("Please Enter a Password!", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}
	if (textBox4->Text->Length != 8)//Lenghth Error
	{
		MessageBox::Show("Password Length must be 8", "INVALID PASSWORD LENGTH", MessageBoxButtons::OK, MessageBoxIcon::Error);
		textBox4->Text = "";
		return;
	}
	if (!ValidatePassword(textBox4->Text))//validation of Password
	{
		MessageBox::Show("Password must contain a Lowercase letter, an Uppercase letter, a Special Symbole and a Digit", "INVALID PASSWORD", MessageBoxButtons::OK, MessageBoxIcon::Error);
		textBox4->Text = "";
		return;
	}
	if (textBox5->Text->Length == 0)//empty Re entered password
	{
		MessageBox::Show("Please Enter Your Confirmation Password!", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}
	if (textBox4->Text != textBox5->Text)//comparision between Password and reentered password
	{
		MessageBox::Show("Please Check Your Password", "INVALID RE-ENTERED PASSWORD", MessageBoxButtons::OK, MessageBoxIcon::Error);
		textBox5->Text = "";
		return;
	}
	//welcome email sending
	try {
		MailMessage^ message = gcnew MailMessage();
		SmtpClient^ smtp = gcnew SmtpClient();
		message->From = gcnew MailAddress("pshlok4105@gmail.com");
		message->To->Add(gcnew MailAddress(textBox3->Text));
		message->Subject = "Welcome To AMS";
		message->IsBodyHtml = true; //to make message body as html  
		message->Body = "<p style=\"font-size:20px;\">Hi "+ textBox1->Text +",</p><br><h2>Welcome to Attendance Managment System.</h2><br><p style=\"font-size:20px;\">we�re excited to have you on boardand we�d love to say thank you on behalf of our whole company for choosing us.We believe our <b>AMS(Attendance Managment System) </b> will help you to manage attendace report daily without any brainstorming.</p><br/><p style=\"font-size:20px;\">In today's competitive world, with increasing working hours and less classroom time, teachers need edTech tools which help them manage precious class time efficiently. Instead of focusing on teaching, faculty members are often stuck with completing formal duties, for e.g. taking daily student attendance.</p><br/><p style=\"font-size:20px;\"> In traditional, the process of takingand managing attendance is very poor.But AMS provides you bestand fast attendance managing system where you can customize attendance reports according to duration, you will get reports precisely on email too.</p><br/><p style=\"font-size:20px;\">An attendance management system's features play a key role in making time and attendance tracking easier. This saves your time and efoort too.</p><br><br><p style=\"font-size:20px;\"> Have any questions or need more information ? Just shoot us an email!We�re always here to help.<br></p><p style=\"font-size:20px;\">Take care,<b><u>AMS</u><b/></p>";
		smtp->Port = 587;
		smtp->Host = "smtp.gmail.com"; //for gmail host  
		smtp->EnableSsl = true;
		smtp->UseDefaultCredentials = false;
		smtp->Credentials = gcnew System::Net::NetworkCredential("pshlok4105@gmail.com", "Shubham1872003@");
		smtp->DeliveryMethod = SmtpDeliveryMethod::Network;
		smtp->Send(message);
		MessageBox::Show("Email is sent to " + textBox3->Text, "WELCOME TO AMS", MessageBoxButtons::OK, MessageBoxIcon::Information);
	}
	catch (Exception^ ex)
	{
		MessageBox::Show("Please Enter a Valid Email Address!", "INVALID EMAIL ADDRESS", MessageBoxButtons::OK, MessageBoxIcon::Error);
		textBox3->Text = "";
		return;
	}
	//Ams Folder creating and data writing
	String^ APP_PATH = Environment::GetFolderPath(Environment::SpecialFolder::MyDocuments) + "\\AMS";
	Directory::CreateDirectory(APP_PATH);
	Directory::CreateDirectory(APP_PATH + "\\LOG-INFO\\APPLOG");
	//File::Create(APP_PATH + "\\LOG-INFO\\login-Credentials.txt");
	//File::Create(APP_PATH + "\\LOG-INFO\\APPLOG\\logs.txt");
	Directory::CreateDirectory(APP_PATH + "\\USER-INFO");
	//File::Create(APP_PATH + "\\USER-INFO\\user-Details.txt");
	Directory::CreateDirectory(APP_PATH + "\\OTHER");
	File::Create(APP_PATH + "\\OTHER\\semester-Record.txt");

	StreamWriter^ sw = gcnew StreamWriter(APP_PATH + "\\USER-INFO\\user-Details.txt");
	sw->WriteLine(textBox1->Text);
	sw->WriteLine(textBox2->Text);
	sw->WriteLine(textBox3->Text->ToLower());
	sw->Close();

	sw = gcnew StreamWriter(APP_PATH + "\\LOG-INFO\\login-Credentials.txt");
	sw->WriteLine(textBox3->Text->ToLower());
	sw->WriteLine(textBox4->Text);
	sw->Close();

	DateTime^ now = DateTime::Now;
	sw = File::AppendText(APP_PATH + "\\LOG-INFO\\APPLOG\\logs.txt");
	sw->WriteLine(now);
	sw->Close();

	MessageBox::Show("Redirecting....", "Correct Password", MessageBoxButtons::OK, MessageBoxIcon::Information);
	Application::Exit();
	
}
//password checking function
bool ValidatePassword(String^ password){
	const int MIN_LENGTH = 8;
	const int MAX_LENGTH = 8;
	bool meetsLengthRequirements = password->Length >= MIN_LENGTH && password->Length <= MAX_LENGTH;
	bool hasUpperCaseLetter = false;
	bool hasLowerCaseLetter = false;
	bool hasDecimalDigit = false;
	bool hasSpecialChar = ISSpecialSymbols(password);
	if (meetsLengthRequirements)
	{
		for(int i=0;i<password->Length;i++)
		{ 
			
			if (Char::IsUpper(password[i])) hasUpperCaseLetter = true;
			else if (Char::IsLower(password[i])) hasLowerCaseLetter = true;
			else if (Char::IsDigit(password[i])) hasDecimalDigit = true;	
		}
	}
	bool isValid = meetsLengthRequirements&& hasUpperCaseLetter && hasLowerCaseLetter && hasDecimalDigit && hasSpecialChar ;
	return isValid;
}

private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
	Application::Exit();
}
};
}
